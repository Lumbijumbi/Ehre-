# AGE14 — How to Use / Manual

Version: 1.0.0  
Author: Lumbijumbi  
Last updated: 2025-11-18

---

Overview
--------
AGE14 is a small REST API wrapper around the datadome-interstital-encryptor Node.js module. It extracts the `dd` configuration object used by DataDome's interstitial challenge (when provided), builds the required signals, encrypts them and returns the encrypted payload that can be used to complete the Datadome interstitial flow.

This manual explains how to install AGE14, run it locally, use its endpoints, and integrate the example client that fetches a page, extracts the `dd` snippet and forwards it to the API automatically.

What I did
----------
I implemented a REST API exposing endpoints to:
- generate an encrypted payload from explicit signals,
- parse an HTML snippet (containing `dd = {...}`) and build signals automatically,
- offer a quick example endpoint with sample values,
- ship an example client that fetches a target page and posts extracted `dd` HTML to the API.

What's next
----------
Use the API locally to generate encrypted payloads, integrate it into any automation that needs to solve Datadome interstitials, and consider hardening the server (HTTPS, auth, rate-limiting) if you deploy it publicly.

Quick Start (local)
-------------------
Prerequisites:
- Node.js 18+ (or LTS)
- npm

1. Clone or copy AGE14 project files to a directory.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```
   - Default port: 3000 (change with `PORT` env var)

4. Open `http://localhost:3000` to view API info.

Available Endpoints
-------------------

GET /
- Basic API info (name, endpoints).

GET /health
- Health check. Returns service status and uptime.

GET /api/encrypt/quick
- Returns an encrypted payload using the sample `dd` values included with AGE14. Useful for quick testing.

POST /api/encrypt
- Generate encrypted payload from explicit signals.
- Body (JSON):
  ```json
  {
    "cid": "string",          // required
    "hash": "string",         // required
    "seed": 4046101435,       // optional
    "signals": [
      ["key1", "value1"],
      ["key2", "value2"]
    ]
  }
  ```
- Response:
  ```json
  {
    "success": true,
    "data": {
      "encryptedPayload": "<string>",
      "signalsCount": 3,
      "signals": { "key1": "value1", ... }
    }
  }
  ```

POST /api/encrypt/from-dd-html
- Extracts a `dd` object from provided HTML, adds the fields as signals, optionally merges user-provided additional signals, and returns the encrypted payload.
- Body (JSON):
  ```json
  {
    "html": "<script>dd = { ... }</script>",   // required
    "additionalSignals": { "user": "value" },   // optional
    "seed": 4046101435                          // optional
  }
  ```
- The server attempts to safely parse the `dd` object with a sandboxed VM. If parsing succeeds, the returned payload includes `signals` and the parsed `ddObject`.

Examples
--------

A. POST /api/encrypt (curl)
```bash
curl -X POST http://localhost:3000/api/encrypt \
  -H "Content-Type: application/json" \
  -d '{
    "cid": "AHrlqAAAAAMAUzrh4e_6ax0A1CMShg==",
    "hash": "4E2D21855D176C1885A97CE16C8EC3",
    "signals": [
      ["rt", "i"],
      ["cid", "AHrlqAAAAAMAUzrh4e_6ax0A1CMShg=="],
      ["hsh", "4E2D21855D176C1885A97CE16C8EC3"],
      ["b", 1880110],
      ["s", 50309],
      ["timestamp", 1699999999999]
    ]
  }'
```

B. POST /api/encrypt/from-dd-html (curl)
```bash
curl -X POST http://localhost:3000/api/encrypt/from-dd-html \
  -H "Content-Type: application/json" \
  -d '{
    "html": "<script>dd={\"cid\":\"AHrlq...\",\"hsh\":\"4E2D...\",\"s\":50309,\"b\":1880110};</script>"
  }'
```

C. Node example (client)
```js
const axios = require('axios');

async function sendSignals() {
  const res = await axios.post('http://localhost:3000/api/encrypt', {
    cid: 'AHrlqAAAAAMAUzrh4e_6ax0A1CMShg==',
    hash: '4E2D21855D176C1885A97CE16C8EC3',
    signals: [
      ['rt','i'],
      ['s', 50309]
    ]
  });
  console.log(res.data.data.encryptedPayload);
}
sendSignals();
```

D. Example client: fetch-and-send (fetch a URL, extract dd snippet and call API)
- Usage:
  ```bash
  node examples/fetch-and-send.js "https://target.page/with/interstitial" "http://localhost:3000"
  ```
- This script:
  - fetches the target page (with a browser user-agent),
  - looks for `dd = { ... }` script snippet,
  - posts the snippet (or full HTML if not found) to `/api/encrypt/from-dd-html`,
  - prints the API response.

Security & Operational Notes
----------------------------
- The server uses a sandboxed Node `vm` to evaluate the `dd` object literal. While this VM usage is constrained (timeout), only feed HTML from trusted sources to the parser if you are concerned about executing untrusted script content.
- If you deploy AGE14 publicly:
  - run behind HTTPS,
  - add authentication (API keys, JWT),
  - add rate-limiting,
  - log securely and rotate logs,
  - sanitize logs so no secrets (cookies or `e` hashes) are leaked,
  - enforce input size limits.
- The `cookie` and other `dd` fields are sensitive — treat payloads as secrets.

Parsing limitations
-------------------
- The parser looks for patterns like:
  - `dd = { ... };`
  - `var dd = { ... };`
  - `dd={ ... }` (followed by `</script>` or end-of-snippet)
- If the `dd` object is obfuscated, generated dynamically or built through function calls, the simple extractor may fail. In those cases, fetch the page in a browser (headless) and obtain the runtime `dd` object from the page context, then post it to the API.

Troubleshooting
---------------
- Error: `Could not locate dd object in HTML`  
  → The HTML posted does not contain a simple object literal matching the parser regex. Try sending the full page HTML (the server will try again) or extract the `dd` JSON manually and post via `/api/encrypt`.

- Error: `Parsed dd object missing required fields (cid, hsh)`  
  → The parsed object does not include `cid` or `hsh` fields. Confirm you have the correct page / snippet where DataDome's `dd` object is defined.

- Timeout fetching remote page in client script  
  → Increase timeout, or fetch the page with a headless browser to handle dynamic generation.

Deployment & Environment
------------------------
- Change port: set `PORT` environment variable before running.
- Run as a service (systemd, pm2, Docker) for production.
- Example Dockerfile (optional):
  ```dockerfile
  FROM node:18-alpine
  WORKDIR /app
  COPY package*.json ./
  RUN npm install --production
  COPY . .
  EXPOSE 3000
  CMD ["node", "server.js"]
  ```

Recommended Next Steps
----------------------
- Add authentication (API key or OAuth) to the API.
- Add rate-limiting or IP throttling.
- Store sensitive payloads temporarily encrypted if you need to persist them.
- Add tests for HTML parsing edge-cases.
- Optionally integrate an automated headless browser fetch (Puppeteer) for pages that generate the `dd` object at run-time.

API Contract Summary
--------------------
- Input: either an array of signals or HTML containing `dd` object.
- Output: JSON with `encryptedPayload` and the signals used.
- Default seed used by the encryptor: `4046101435` (override via `seed`).

Contributing
------------
- Fork the repo, make changes, open a pull request.
- Add unit tests for parsing rules when adding new parsing logic.
- Keep secrets out of the repo.

License
-------
- Default MIT (or the license you set for your project).

Contact
-------
For help, or if you want me to add additional features (auth, rate limiting, persistent storage, headless fetcher), tell me which one to implement next and I’ll modify the API accordingly.