'use strict';

const { parseDDObjectFromHTML } = require('../lib/parser');

describe('parseDDObjectFromHTML', () => {
  test('parses simple dd object with var', () => {
    const html = '<script>var dd = {cid: "CID_X", hsh: "HSH_Y", s: 123};</script>';
    const dd = parseDDObjectFromHTML(html);
    expect(dd).toBeDefined();
    expect(dd.cid).toBe('CID_X');
    expect(dd.hsh).toBe('HSH_Y');
    expect(dd.s).toBe(123);
  });

  test('parses dd object without var and with semicolon', () => {
    const html = '<script>dd = { "cid": "A", "hsh": "B", "b": 5 };</script>';
    const dd = parseDDObjectFromHTML(html);
    expect(dd.cid).toBe('A');
    expect(dd.hsh).toBe('B');
    expect(dd.b).toBe(5);
  });

  test('throws when no dd object present', () => {
    const html = '<html><body>no dd here</body></html>';
    expect(() => parseDDObjectFromHTML(html)).toThrow(/Could not locate dd object/i);
  });

  test('fails on non-string html', () => {
    expect(() => parseDDObjectFromHTML(null)).toThrow(/html must be a string/i);
  });
});