'use strict';

/**
 * Integration test for the Puppeteer-backed endpoint (/api/encrypt/from-url).
 *
 * This test will be skipped unless CHROME_PATH is provided (to avoid failing
 * in environments without Chromium).
 *
 * The test spins up:
 *  - the main app (on a random port)
 *  - a tiny HTTP server that serves a page with window.dd defined
 *
 * Then it posts to /api/encrypt/from-url and expects a successful response
 * containing the ddObject returned by the Puppeteer fetcher.
 */

const http = require('http');
const request = require('supertest');
const app = require('../app');

const runIfChrome = process.env.CHROME_PATH ? test : test.skip;

runIfChrome('POST /api/encrypt/from-url (puppeteer end-to-end)', async () => {
  // start the main app
  const server = app.listen(0);
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;

  // start a tiny page server that serves a dd-containing page
  const ddHtml = `<html><head></head><body>
    <script>
      window.dd = { cid: "CID-INT", hsh: "HSH-INT", s: 1, b: 2 };
    </script>
  </body></html>`;

  const pageServer = http.createServer((req, res) => {
    if (req.url === '/dd') {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(ddHtml);
    } else {
      res.writeHead(404);
      res.end('not found');
    }
  });

  await new Promise(resolve => pageServer.listen(0, resolve));
  const pagePort = pageServer.address().port;
  const pageUrl = `http://127.0.0.1:${pagePort}/dd`;

  try {
    // Ensure server returns 200 and then call the endpoint
    const res = await request(base)
      .post('/api/encrypt/from-url')
      .send({ url: pageUrl })
      .set('Content-Type', 'application/json')
      .timeout({ deadline: 60000 }); // allow longer for puppeteer

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('ddObject');
    expect(res.body.data.ddObject.cid).toBe('CID-INT');
  } finally {
    server.close();
    pageServer.close();
  }
}, 60000);