'use strict';

// Mock the datadome-interstital-encryptor so tests don't depend on the real implementation
jest.mock('datadome-interstital-encryptor', () => {
  return jest.fn().mockImplementation((cid, hsh, seed) => {
    const signals = {};
    return {
      addSignal: (k, v) => {
        signals[k] = v;
      },
      getPayload: () => {
        // return a deterministic string so assertions are easy
        return `payload:${cid}:${hsh}:${Object.keys(signals).length}`;
      },
      getSignals: () => signals
    };
  });
});

const request = require('supertest');
const app = require('../app');

describe('API endpoints', () => {
  test('GET / returns API info', async () => {
    const res = await request(app).get('/');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('name');
  });

  test('GET /health returns ok', async () => {
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  test('GET /api/encrypt/quick returns payload', async () => {
    const res = await request(app).get('/api/encrypt/quick');
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('encryptedPayload');
    // payload begins with 'payload:'
    expect(res.body.data.encryptedPayload).toMatch(/^payload:/);
  });

  test('POST /api/encrypt validates input', async () => {
    const res = await request(app).post('/api/encrypt').send({ hash: 'hsh' });
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
  });

  test('POST /api/encrypt succeeds with valid signals', async () => {
    const body = {
      cid: 'C1',
      hash: 'H1',
      signals: [
        ['k1', 'v1'],
        ['k2', 2]
      ]
    };
    const res = await request(app).post('/api/encrypt').send(body);
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.signalsCount).toBe(2);
    expect(res.body.data.encryptedPayload).toContain('payload:C1:H1');
  });

  test('POST /api/encrypt/from-dd-html parses dd and returns payload', async () => {
    const html = '<script>dd={cid:"CIDX", hsh:"HSHY", s:100, b:200};</script>';
    const res = await request(app).post('/api/encrypt/from-dd-html').send({ html });
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('encryptedPayload');
    expect(res.body.data).toHaveProperty('ddObject');
    expect(res.body.data.ddObject.cid).toBe('CIDX');
  });

  test('POST /api/encrypt/from-dd-html returns error when html missing', async () => {
    const res = await request(app).post('/api/encrypt/from-dd-html').send({});
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
  });

  test('POST /api/encrypt/from-dd-html returns error when dd missing required fields', async () => {
    const html = '<script>dd={foo:"bar"};</script>';
    const res = await request(app).post('/api/encrypt/from-dd-html').send({ html });
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
  });
});