```markdown
# Datadome Interstitial Encryptor API (AGE14)

Local dev + test instructions

Install:
  npm install

Run:
  npm start

Run tests:
  npm test

Notes:
- The tests mock the datadome-interstital-encryptor module to keep unit tests deterministic.
- For real runs, the actual datadome-interstital-encryptor will be used.

``` 