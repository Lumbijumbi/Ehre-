#!/usr/bin/env node
/**
 * Example CLI that uses the puppeteer-core fetcher to retrieve the runtime dd object from a URL
 * and POSTs it to the local API (/api/encrypt/from-dd-html by wrapping it as JSON).
 *
 * Usage:
 *   node examples/fetch-dd-puppeteer.js <url> [apiBase]
 *
 * Example:
 *   CHROME_PATH=/usr/bin/chromium-browser node examples/fetch-dd-puppeteer.js "https://site-with-interstitial" "http://localhost:3000"
 *
 * Note: Requires puppeteer-core installed and a Chromium binary available.
 */

const axios = require('axios');
const { fetchDdFromUrl } = require('../lib/puppeteer-fetcher');

async function main() {
  const target = process.argv[2];
  const apiBase = process.argv[3] || 'http://localhost:3000';

  if (!target) {
    console.error('Usage: node examples/fetch-dd-puppeteer.js <url> [apiBase]');
    process.exit(1);
  }

  console.log('Fetching dd from:', target);
  try {
    const dd = await fetchDdFromUrl(target, {
      timeout: 20000,
      headless: true,
      executablePath: process.env.CHROME_PATH
    });
    if (!dd) {
      console.error('No window.dd found on the page.');
      process.exit(2);
    }
    console.log('Found dd object:', JSON.stringify(dd, null, 2));

    // POST to local API
    const resp = await axios.post(`${apiBase.replace(/\/$/, '')}/api/encrypt/from-dd-html`, {
      html: `<script>dd = ${JSON.stringify(dd)};</script>`,
      additionalSignals: { fetchedBy: 'puppeteer-cli' }
    });
    console.log('API response:', resp.data);
  } catch (err) {
    console.error('Error fetching or posting dd:', err.message || err);
    process.exit(3);
  }
}

if (require.main === module) {
  main();
}