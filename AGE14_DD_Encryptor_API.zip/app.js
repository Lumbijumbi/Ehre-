'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const { parseDDObjectFromHTML } = require('./lib/parser');
const InterstitalEncryptor = require('datadome-interstital-encryptor');
const { validate, schemas } = require('./lib/validation');

const app = express();

app.use(cors());
app.use(bodyParser.json({ limit: '1mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

// Simple logger (skip when NODE_ENV=test)
if (process.env.NODE_ENV !== 'test') {
  app.use((req, res, next) => {
    // eslint-disable-next-line no-console
    console.log(`${new Date().toISOString()} ${req.method} ${req.path}`);
    next();
  });
}

app.get('/', (req, res) => {
  res.json({
    name: 'Datadome Interstitial Encryptor API (AGE14)',
    version: '1.0.0',
    endpoints: {
      encrypt: 'POST /api/encrypt',
      'encrypt-from-dd-html': 'POST /api/encrypt/from-dd-html',
      quick: 'GET /api/encrypt/quick',
      'encrypt-from-url (optional)': 'POST /api/encrypt/from-url (requires ENABLE_PUPPETEER=1)'
    }
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

app.get('/api/encrypt/quick', (req, res) => {
  try {
    const cid = 'AHrlqAAAAAMAUzrh4e_6ax0A1CMShg==';
    const hash = '4E2D21855D176C1885A97CE16C8EC3';
    const seed = 4046101435;

    const encryptor = new InterstitalEncryptor(cid, hash, seed);
    const defaultSignals = [
      ['rt', 'i'],
      ['cid', cid],
      ['hsh', hash],
      ['b', 1880110],
      ['s', 50309],
      [
        'e',
        '4fd905f924693f7e3bcea3b66b0ee15a3a3d2a30f4a31040ebeb72c18ac049b159cadbedee1a7c105989a203c24b448e'
      ],
      ['qp', ''],
      ['host', 'geo.captcha-delivery.com'],
      [
        'cookie',
        'RcFTe7429bz2uctnzF8LpT~bogeqm0DQSmP8HhTqtg37Qmg_QZPI1kAUvSw7P36UvbIY8pJX7kEjAGfSq5JEIRa3E4KQHNpKG~SaboNPIV6R5ZXpuT3TvKC0l36qib8F'
      ],
      ['timestamp', Date.now()]
    ];
    defaultSignals.forEach(s => encryptor.addSignal(s[0], s[1]));
    const payload = encryptor.getPayload();
    res.json({ success: true, data: { encryptedPayload: payload, signals: encryptor.getSignals() } });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Error /api/encrypt/quick', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/encrypt
 * Body: { cid, hash, seed?, signals: [ [key, value], ... ] }
 */
app.post('/api/encrypt', validate(schemas.encryptSchema), (req, res) => {
  try {
    const { cid, hash, seed, signals } = req.body;

    const encryptor = new InterstitalEncryptor(cid, hash, seed || 4046101435);
    signals.forEach(s => {
      if (!Array.isArray(s) || s.length < 2) return;
      encryptor.addSignal(s[0], s[1]);
    });

    const payload = encryptor.getPayload();
    return res.json({
      success: true,
      data: {
        encryptedPayload: payload,
        signalsCount: signals.length,
        signals: encryptor.getSignals()
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Error /api/encrypt', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/encrypt/from-dd-html
 * Body: { html: "<script>dd = {...}</script>", additionalSignals?: { key: value }, seed? }
 */
app.post('/api/encrypt/from-dd-html', validate(schemas.fromDdHtmlSchema), (req, res) => {
  try {
    const { html, additionalSignals = {}, seed } = req.body;

    const dd = parseDDObjectFromHTML(html);

    if (!dd || !dd.cid || !dd.hsh) {
      return res.status(400).json({ success: false, error: 'Parsed dd object missing required fields (cid, hsh)' });
    }

    const cid = dd.cid;
    const hash = dd.hsh;
    const encryptorSeed = seed || 4046101435;
    const encryptor = new InterstitalEncryptor(cid, hash, encryptorSeed);

    // Build signals from dd object (include keys that commonly exist)
    const ddSignals = {
      rt: dd.rt,
      cid: dd.cid,
      hsh: dd.hsh,
      b: dd.b,
      s: dd.s,
      e: dd.e,
      qp: dd.qp,
      host: dd.host,
      cookie: dd.cookie,
      cp: dd.cp,
      p: dd.p,
      rr: dd.rr,
      sfcc: dd.sfcc,
      requestUrl: dd.requestUrl
    };

    Object.entries(ddSignals).forEach(([k, v]) => {
      if (typeof v !== 'undefined') encryptor.addSignal(k, v);
    });

    if (additionalSignals && typeof additionalSignals === 'object') {
      Object.entries(additionalSignals).forEach(([k, v]) => {
        encryptor.addSignal(k, v);
      });
    }

    if (!encryptor.getSignals().timestamp) {
      encryptor.addSignal('timestamp', Date.now());
    }

    const payload = encryptor.getPayload();

    res.json({
      success: true,
      data: {
        encryptedPayload: payload,
        signals: encryptor.getSignals(),
        ddObject: dd
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Error /api/encrypt/from-dd-html', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/encrypt/from-url
 * Body: { url: string, additionalSignals?: {}, seed?: number, waitForDd?: boolean }
 *
 * This endpoint uses Puppeteer to fetch the page and read window.dd at runtime.
 * Only enabled if ENABLE_PUPPETEER=1 environment variable is set (safety gate).
 */
app.post('/api/encrypt/from-url', validate(schemas.fromUrlSchema), async (req, res) => {
  if (process.env.ENABLE_PUPPETEER !== '1') {
    return res.status(501).json({
      success: false,
      error: 'Puppeteer fetcher is not enabled on this server. Set ENABLE_PUPPETEER=1 to enable.'
    });
  }

  const { url, additionalSignals = {}, seed } = req.body;
  let fetcher;
  try {
    fetcher = require('./lib/puppeteer-fetcher');
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: 'Puppeteer support not available. Ensure puppeteer is installed.'
    });
  }

  try {
    const dd = await fetcher.fetchDdFromUrl(url, { timeout: 20000, headless: true });
    if (!dd || !dd.cid || !dd.hsh) {
      return res.status(400).json({
        success: false,
        error: 'Unable to obtain dd object from the page or dd is missing cid/hsh'
      });
    }

    const cid = dd.cid;
    const hash = dd.hsh;
    const encryptorSeed = seed || 4046101435;
    const encryptor = new InterstitalEncryptor(cid, hash, encryptorSeed);

    const ddSignals = {
      rt: dd.rt,
      cid: dd.cid,
      hsh: dd.hsh,
      b: dd.b,
      s: dd.s,
      e: dd.e,
      qp: dd.qp,
      host: dd.host,
      cookie: dd.cookie,
      cp: dd.cp,
      p: dd.p,
      rr: dd.rr,
      sfcc: dd.sfcc,
      requestUrl: dd.requestUrl
    };

    Object.entries(ddSignals).forEach(([k, v]) => {
      if (typeof v !== 'undefined') encryptor.addSignal(k, v);
    });

    if (additionalSignals && typeof additionalSignals === 'object') {
      Object.entries(additionalSignals).forEach(([k, v]) => {
        encryptor.addSignal(k, v);
      });
    }

    if (!encryptor.getSignals().timestamp) {
      encryptor.addSignal('timestamp', Date.now());
    }

    const payload = encryptor.getPayload();

    return res.json({
      success: true,
      data: {
        encryptedPayload: payload,
        signals: encryptor.getSignals(),
        ddObject: dd
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Error /api/encrypt/from-url', err);
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

module.exports = app;